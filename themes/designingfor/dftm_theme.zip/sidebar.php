<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>
		<div id="sidebar">
			<div id="search">
				<?php get_search_form(); ?>
			</div>
			
			<div id="advertisement">
				<a href="#" class="image"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/ad.jpg" alt="" width="200" /></a>
			</div>
			
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
		
		
			<div>
				<p>NOTE: No Widgets found. Don't forget to activate some widgets in the WP Admin tool.</p>
			</div>
		
			<?php endif; ?>
		</div>

